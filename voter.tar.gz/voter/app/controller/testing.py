from cerberus import Validator

schema={
"name": {
    "type": "string",
},

"travel_details": {
    'type': 'dict',
    'allow_unknown': True,
    'schema': {
    "num_of_adults": {
        "type": "string",
    }
    }
}

}
v = Validator(schema)
jsondata={"name":"jayesh","travel_details":{"num_of_adults":"54"}}
status = v.validate(jsondata)    

print(status)



# 'name': {'type': 'string'},
# 'a_dict': {
# 'type': 'dict',
# 'allow_unknown': True, # this overrides the behaviour for
# 'schema': { # the validation of this definition

# 'address': {'type': 'string'}
# }
# }
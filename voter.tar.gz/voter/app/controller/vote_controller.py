from app.model import voterdao
import json 
from cerberus import Validator


# this function for save votes
def vote_entery(jsondata):
    name=jsondata["name"]
    voterid=jsondata["voterid"]

    try:
        str(name)
    except:
        return "invalid name field"

    try:
        int(voterid)
    except:
        return "invalid voterid field"
    ret =None
    ret1=None
    ret3=voterdao.check_exist(name)
    if ret3:
        return "voter already exist"
    else:
        ret1=voterdao.get_vote_count(voterid)
        count=ret1[1]
        ret2=voterdao.save_vote_count(voterid,int(count)+1)

    ret=voterdao.save_vote(name,voterid) 
    return "thank you for voting"

#this function for check admin athentication
def check_admin(user_name,password):
    error="User name or password Invalid"
    if user_name == "admin" and password == "admin@123":
        return "success"
    else:
        return error

# this function is for get voting information and display
def get_vote_info():
    
    val="<body><table style='text-align:center'>"
    ret =None 
    ret1=voterdao.get_max_count()

    ret=voterdao.get_vote_info() 
    for row in ret:
        if row[0]==ret1[0]:
            val+="<tr bgcolor=#FF0000><td>"+row[0]+"</td><td>"+row[1]+"</td><td>"+row[2]+"</td></tr>"
        else:
            val+="<tr><td>"+row[0]+"</td><td>"+row[1]+"</td><td>"+row[2]+"</td></tr>"
    val+="</table></body>"
    return val
from app.model import database_connection as database
from datetime import datetime
cursor = None

def opencursor1():           
    conn=database.pool_db.get_connection()
    cursor=conn.cursor(buffered=True)
    return conn,cursor
            
def closecursor(conn,cursor):
    cursor.close()
    conn.close()

def save_vote(name,voterid):
    conn,cursor=opencursor1()   
    data=None
    sql="INSERT INTO voter_table(name,voterid)values('"+str(name)+"','"+voterid+"')"
    print sql
  
    try:
        cursor.execute(sql)
        conn.commit()
        data="success"

    except Exception as e:
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data
 
 # mysql query for save votes 
def save_vote_count(voterid,votecount):
    conn,cursor=opencursor1()   
    data=None
    sql="update party_table set votecount="+str(votecount)+" where p_id="+voterid
    print sql
  
    try:
        cursor.execute(sql)
        conn.commit()
        data="success"

    except Exception as e:
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data

# mysql query for get voting information 
def get_vote_info():
    data = None
    conn,cursor=opencursor1()
    sql="select p_id, party_name,votecount from party_table"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        print(str(e))
        data = "DBError"
    closecursor(conn,cursor)
    return data

# mysql query for get vite count
def get_vote_count(p_id):
    data = None
    conn,cursor=opencursor1()
    sql="select p_id, votecount from party_table where p_id="+p_id
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchone()
    except Exception as e:
        print(str(e))
        data = "DBError"
    closecursor(conn,cursor)
    return data

# mysql query for check voter already voted
def check_exist(name):
    data = None
    conn,cursor=opencursor1()
    sql="SELECT * from voter_table where binary name='"+str(name)+"'"
    print(sql)
    try:
        cursor.execute(sql)
        data = cursor.fetchone()
    except Exception as e:
        print(str(e))
        data = "DBError"
    closecursor(conn,cursor)
    return data
  
# mysql query for get count of maximum votes
def get_max_count():
    data = None
    conn,cursor=opencursor1()
    sql="SELECT p_id, MAX(votecount) FROM party_table"
    try:
        cursor.execute(sql)
        data = cursor.fetchone()
    except Exception as e:
        print(str(e))
        data = "DBError"
    closecursor(conn,cursor)
    return data



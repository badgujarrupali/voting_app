function voter() {
    var name = $("#1").val()
    var voterid = $("#2").val()

    content = {
        name: name,
        voterid: voterid
    }
    $.ajax({
        url: '/submitVote',
        data: content,
        type: 'POST',
        data: JSON.stringify(content),
        contentType: 'application/json; charset=utf-8',
        success: function (response) {
            if (Response == "success") {
                console.log(response);
                alert("thank you for voting")
            }
            else {
                alert(response)
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}
function admin() {
    var user_name = $("#1").val()
    var password = $("#2").val()

    content = {
        user_name: user_name,
        password: password
    }
    $.ajax({
        url: '/checkAdmin',
        data: content,
        type: 'POST',
        success: function (response) {
            if (response == "success") {
                console.log(response);
                window.location.href = "/voteInfo"
            }
            else {
                alert(response)
            }



        },
        error: function (error) {
            alert(error);
        }
    });
} 

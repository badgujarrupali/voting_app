from app import app
from flask import request, render_template
from app.controller import vote_controller

#this is for first frontend index call
@app.route('/',methods=['GET','POST'])
def index():
    return render_template("index.html")

#this is for admin enrty 
@app.route('/admin',methods=['GET','POST'])
def admin():
    return render_template("admin.html")

#this is for vote entry 
@app.route('/voter',methods=['GET','POST'])
def voter():
    return render_template("voter.html")
    
#this is for submit the votes 
@app.route('/submitVote', methods=['GET', 'POST'])
def submitVote():
    data = None
    if request.method == 'POST':
        data = vote_controller.vote_entery(request.json)
        return data

#this is for first adimn authentication check
@app.route('/checkAdmin', methods=['GET', 'POST'])
def checkAdmin():
    data = None
    if request.method == 'POST':
        data = vote_controller.check_admin(request.form['user_name'],request.form['password'])
        return data
 
#this is for total  voting information call
@app.route('/voteInfo',methods=['GET','POST'])
def vote_info():
    if request.method=='GET':
        data = None
        data = vote_controller.get_vote_info()
        return data